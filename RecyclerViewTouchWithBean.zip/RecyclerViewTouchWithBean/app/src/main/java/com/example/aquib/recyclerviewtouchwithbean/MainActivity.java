package com.example.aquib.recyclerviewtouchwithbean;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;

import java.util.ArrayList;

public class MainActivity extends AppCompatActivity {

    private ArrayList<Bean> nameList = new ArrayList<>();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        getdata();
        getId();
    }

    private void getdata() {

        Bean bean1 = new Bean("Rahul", "Riya");
        Bean bean2 = new Bean("Ramesh", "Sushmita");
        Bean bean3 = new Bean("Suresh", "Aishwarya");
        Bean bean4 = new Bean("Dinesh", "Rupa");
        Bean bean5 = new Bean("Ravi", "Deepika");
        Bean bean6 = new Bean("Vikky", "Kritika");
        Bean bean7 = new Bean("Vikram", "Diya");
        Bean bean8 = new Bean("Kartik", "Radhika");
        nameList.add(bean1);
        nameList.add(bean2);
        nameList.add(bean3);
        nameList.add(bean4);
        nameList.add(bean5);
        nameList.add(bean6);
        nameList.add(bean7);
        nameList.add(bean8);

    }

    private void getId() {
        RecyclerView mRecyclerView = (RecyclerView) findViewById(R.id.recycler);
        RecyclerView.LayoutManager LayoutManager = new LinearLayoutManager(MainActivity.this);

        mRecyclerView.setHasFixedSize(true);
        mRecyclerView.setLayoutManager(LayoutManager);

        RecyclerAdapter adapter = new RecyclerAdapter(MainActivity.this, nameList);
        mRecyclerView.setAdapter(adapter);

    }
}
